void carregarComandos(); 
void tratarExpressoes(char *line); 
int calculaChaveExpressao(const char * expressao); 
unsigned int proximoComando(void); 
char *expressaoAtual(void); 
char *comandoAtual(void); 
int ehNumero (char c); 